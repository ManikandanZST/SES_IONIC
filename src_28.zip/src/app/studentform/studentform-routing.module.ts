import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentFormPage } from './studentform.page';
const routes: Routes = [
  {
    path: '',
    component: StudentFormPage
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentFormPageRoutingModule {}
