export const environment = {
  production: true,
  base_url: 'https://zerosofttech.com/',
  stripePublishableKey : "pk_live_51OlHIZF6UR8YQMJJsal0byEjZzxRvE0wCCf2jJfdDh8gAvaPMb2F17DO5ayqZJxJ2AiHt3SvVg7rdTrVEJJ9LPll00aOsvZvx7",
  // stripePublishableKey : "pk_test_51OlHIZF6UR8YQMJJeJxlWqcVkzyfWXXeYlePHc0e9ypzml5Nz7OBWBBx1O4iLclHyM1ipil5hVvOkWZgb08V5sST009pImwiKS"

};
