# SES mobile APP
Requirements:
Angular
Ionic & cordova
node version 16.18
